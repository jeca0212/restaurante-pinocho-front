import Layout from '@/components/Layout';
import { Register } from './register';




const pageRegister = () => {
    return (
      <Layout>
        <Register/>
      </Layout>
    );
  };
  export default pageRegister;
import Layout from "@/components/Layout";
import { Login } from "./form";


export default function LoginPage() {
  return (
    
      <Layout>
        <Login />
      </Layout>
    
  );
}
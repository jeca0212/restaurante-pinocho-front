import Layout from "@/components/Layout";
import { CartaPinocho } from "./carta";


const Carta = () => {
  return (
    <Layout>
      <CartaPinocho/>
    </Layout>
  );
};
export default Carta;

import Layout from "@/components/Layout";

const Events = () => {
  return (
    <Layout>
      <h1>Restaurante pinocho</h1>
    </Layout>
  );
};
export default Events;
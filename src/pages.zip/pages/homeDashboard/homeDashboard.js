export default function AdminDashboard() {
    return (
        <h1>Hola Laura, Bienvenida a tu panel de control!</h1>
    )

}
import { NavbarDashboard } from "@/components/NavbarDashboard";
import GestionReservas  from "./gestionReservas";



 const indexGestionReservas = () => {
  return (
    <div>
        <NavbarDashboard/>
    
      <GestionReservas/>
    </div>
  );
}
export default indexGestionReservas;
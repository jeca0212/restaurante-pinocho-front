import Layout from "@/components/Layout";
import { MenuPinocho } from "./menus";


const Menu = () => {
  return (
    <Layout>
      <MenuPinocho/>
    </Layout>
  );
};
export default Menu;
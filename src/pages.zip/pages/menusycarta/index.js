import { NavbarDashboard } from "@/components/NavbarDashboard";
import CartaMenu from "./menusycarta";

function menusChange() {
  return (
    <>
        <NavbarDashboard/>
      <CartaMenu />
  
    </>
  );

}
export default menusChange;
